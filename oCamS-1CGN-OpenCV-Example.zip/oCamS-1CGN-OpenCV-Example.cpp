// oCamS-1CGN-OpenCV-Example.cpp
//

#include "stdafx.h"
#include <Windows.h>
#include <mutex>

#include "libCamCap.h"
#if defined(_WIN64)
#pragma comment(lib, "libCamCap-amd64.lib")
#else
#pragma comment(lib, "libCamCap-x86.lib")
#endif

#include <opencv2/opencv.hpp>
#define WINDOW_NAME_1 "Display RIGHT"
#define WINDOW_NAME_2 "Display LEFT"

int g_oCamS_U3[][3] =
{
    { 640,360, 6000 },
    { 640,480, 4500 },
	{ 1280,720, 6000 },
	{ 1280,960, 4500 },
};

cv::Mat g_matGrab;
cv::Mat g_matColorLatest[2];

std::mutex g_mutexImage;

void CallbackFunction(void *pParam, void *pData)
{
	static cv::Mat matSplit[2];
	g_mutexImage.lock();

#if 0
    memcpy(g_matGrab.data, pData, g_matGrab.size().width * g_matGrab.size().height * 2);
#else
	g_matGrab.data = (uint8_t *)pData; // more fast
#endif
	cv::split(g_matGrab, matSplit);

    cv::cvtColor(matSplit[0], g_matColorLatest[0], CV_BayerGR2RGB);
    cv::cvtColor(matSplit[1], g_matColorLatest[1], CV_BayerGR2RGB);
	g_mutexImage.unlock();
}

int GetImages(cv::Mat& matImage1, cv::Mat& matImage2)
{
	int ret = 0;
	g_mutexImage.lock();
	if (g_matColorLatest[0].data) {
		g_matColorLatest[0].copyTo(matImage1);
		ret++;
	}
		
	
	if (g_matColorLatest[1].data)
	{
		g_matColorLatest[1].copyTo(matImage2);
		ret++;
	}
		
	g_mutexImage.unlock();
	return ret>>1;
}

int main()
{
    CAMPTR pCam;
    int nCamIdx = 0;
    int nResolution = 0;
    int nWidth = g_oCamS_U3[nResolution][0];
    int nHeight = g_oCamS_U3[nResolution][1];
    int nFPS = g_oCamS_U3[nResolution][2];
	int nCamCnt;
	bool bRun = true;

    // Create Image Buffer
    g_matGrab = cv::Mat(cv::Size(nWidth, nHeight), CV_8UC2);

    // Camera Open & Capture Start
    pCam = CamOpen(nCamIdx, nWidth, nHeight, nFPS, CallbackFunction, NULL);
    CamStart(pCam);

    cv::namedWindow(WINDOW_NAME_1, cv::WINDOW_AUTOSIZE);
    cv::namedWindow(WINDOW_NAME_2, cv::WINDOW_AUTOSIZE);
	cv::waitKey(100);

	cv::Mat matStereoColorImage[2];
    
    while (bRun)
    {
		int ret;
		ret = GetImages(matStereoColorImage[0], matStereoColorImage[1]);
		if (ret != 1) continue;
		
		
        cv::imshow(WINDOW_NAME_1, matStereoColorImage[0]);
        cv::imshow(WINDOW_NAME_2, matStereoColorImage[1]);

		long gain = 0, exposure = 0;
		long min = 0, max = 0;
		int key = cv::waitKey(10);
		switch (key)
		{
		case 'q':
		case 'Q':
			bRun = false;
			break;
		case '1':
			CamGetCtrlRange(pCam, CTRL_GAIN, &min, &max);
			CamGetCtrl(pCam, CTRL_GAIN, &gain); printf("get gain : %ld\r\n", gain);
			gain += 10;
			if (gain > max) gain = max;
			else if (gain < min) gain = min;
			CamSetCtrl(pCam, CTRL_GAIN, gain); printf("set gain : %ld\r\n", gain);
			break;
		case '2':
			CamGetCtrlRange(pCam, CTRL_GAIN, &min, &max);
			CamGetCtrl(pCam, CTRL_GAIN, &gain); printf("get gain : %ld\r\n", gain);
			if (gain > max) gain = max;
			else if (gain < min) gain = min;
			gain -= 10;
			CamSetCtrl(pCam, CTRL_GAIN, gain); printf("set gain : %ld\r\n", gain);
			break;
		case '3':
			CamGetCtrlRange(pCam, CTRL_EXPOSURE, &min, &max);
			CamGetCtrl(pCam, CTRL_EXPOSURE, &exposure); printf("get exposure : %ld\r\n", exposure);
			exposure += 1;
			if (exposure > max) exposure = max;
			else if (exposure < min) exposure = min;
			CamSetCtrl(pCam, CTRL_EXPOSURE, exposure); printf("set exposure : %ld\r\n", exposure);
			break;
		case '4':
			CamGetCtrlRange(pCam, CTRL_EXPOSURE, &min, &max);
			CamGetCtrl(pCam, CTRL_EXPOSURE, &exposure); printf("get exposure : %ld\r\n", exposure);
			exposure -= 1;
			if (exposure > max) exposure = max;
			else if (exposure < min) exposure = min;
			CamSetCtrl(pCam, CTRL_EXPOSURE, exposure); printf("set exposure : %ld\r\n", exposure);
			break;
		case 's':
			cv::imwrite("RightImage.png", matStereoColorImage[0]);
			cv::imwrite("LeftImage.png", matStereoColorImage[1]);
			break;
		}
    }
    cv::destroyAllWindows();
    CamStop(pCam);
    CamClose(pCam);

    return 0;
}

